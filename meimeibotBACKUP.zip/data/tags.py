tags = {
    "embed_perms": {
        "title": "How do I get embed perms?",
        "description": "To obtain embed permissions, you need to reach Level 10. Once you reach Level 10, you can send embedded links, images, and GIFs in general chat and other channels."
    },
    "ticket": {
        "title": "[DEPRECATED] How do I make a ticket?",
        "description": "To make a ticket type `m!ticket <description>` into a channel! Make sure not to use '<description>' as your description." 
    },
    "8ball": {
        "title": "How does `m!8ball` work?",
        "description": "`m!8ball` gives a random response by choosing from a predefined list of answers."
    },
    "1": {
        "title": "Glorify God",
        "description": "Honor Christ in everything you say and do within this community."
    },
    "2": {
        "title": "Keep His Commandments",
        "description": "\"If you love Me, keep My commandments.\""
    },
    "3": {
        "title": "No Blasphemy",
        "description": "Do not mock God, Jesus Christ, the Holy Spirit, or the Bible, nor misuse His name in vain."
    },
    "4": {
        "title": "No False Teachings or Heresy",
        "description": "Do not teach or spread doctrines that contradict the core truths of the Gospel. Unbiblical, false, or deceptive teachings will be removed."
    },
    "5": {
        "title": "Do Not Promote Sin",
        "description": "Do not encourage, justify, glorify, or celebrate sinful behavior or lifestyles."
    },
    "6": {
        "title": "Be Respectful",
        "description": "No insults, harassment, or personal attacks against any member."
    },
    "7": {
        "title": "No Racism, Hate Speech, or Slurs",
        "description": "Discriminatory language, hate speech, slurs, or racism of any kind will not be tolerated."
    },
    "8": {
        "title": "No Toxicity, Gossip, or Drama",
        "description": "No bullying, slander, passive-aggressive remarks, or intentional stirring up of conflict."
    },
    "9": {
        "title": "No Trolling or Baiting",
        "description": "Do not intentionally provoke, antagonize, or bait others into arguments or anger."
    },
    "10": {
        "title": "Healthy & Respectful Debates",
        "description": "Theological and open discussions are welcome, but must remain peaceful, humble, and respectful. Debates that degenerate into hostility or arrogance will be shut down."
    },
    "11": {
        "title": "Encourage One Another",
        "description": "Seek to build others up, uplift the brokenhearted, and pray for one another in Christ."
    },
    "12": {
        "title": "Strict Policy on NSFW Content",
        "description": "Posting, linking, or sharing any explicit, pornographic, suggestive, or NSFW content (including text, images, memes, or links) is strictly prohibited. Violations are handled with extreme strictness and are very likely to result in a ban."
    },
    "13": {
        "title": "Keep Profiles Appropriate",
        "description": "Usernames, avatars, custom statuses, and bios must remain clean, wholesome, and free of offensive, NSFW, or anti-Christian imagery or text."
    },
    "14": {
        "title": "No Spamming or Flooding",
        "description": "No flooding channels with messages, symbols, images, excessive capital letters, or mass and unnecessary pings."
    },
    "15": {
        "title": "Use Channels Properly",
        "description": "Keep discussions relevant to the designated purpose of each channel."
    },
    "16": {
        "title": "No Evil or Illegal Activities",
        "description": "No doxxing, threats, violent threats, hacking discussions, piracy, or harmful activities of any kind."
    },
    "17": {
        "title": "No Sharing Personal Information",
        "description": "Protect your own privacy and respect the privacy of others. Do not share private personal details, photos, or private conversations."
    },
    "18": {
        "title": "No Scamming, Phishing, or Impersonation",
        "description": "Be honest. Do not impersonate staff, other members, or public figures, and never post phishing, scam, or malicious links."
    },
    "19": {
        "title": "No Advertising or Self-Promotion",
        "description": "Unsolicited self-promotion, advertising other Discord servers, or DM advertising is strictly prohibited unless given explicit permission by staff."
    },
    "20": {
        "title": "Respect Staff & Moderation Decisions",
        "description": "Follow staff instructions promptly. Do not argue with moderators in public channels; if you wish to appeal or discuss a decision, open a ticket or contact staff privately."
    },
    "21": {
        "title": "Only Ping Staff When Necessary",
        "description": "Do not ping admins or moderators for minor reasons, non-urgent issues, or casual chatting. Use proper support channels or tickets."
    },
    "22": {
        "title": "No Role or Perk Begging",
        "description": "Do not beg, pressure, or badger staff for roles, permissions, or special privileges."
    },
    "23": {
        "title": "Follow Discord Terms of Service",
        "description": "All members must fully comply with Discord's Terms of Service and Community Guidelines."
    }
}