import asyncio
import os

import discord
from discord.ext import commands

from config import TOKEN_PATH

intents = discord.Intents.default()
intents.message_content = True
intents.members = True

bot = commands.Bot(command_prefix=["m!","."], intents=intents)


async def load_cogs():
    for filename in os.listdir("./cogs"):
        if filename.endswith(".py"):
            await bot.load_extension(f"cogs.{filename[:-3]}")


async def main():
    async with bot:
        await load_cogs()

        with open(TOKEN_PATH) as f:
            token = f.read().strip()

        await bot.start(token)


asyncio.run(main())
