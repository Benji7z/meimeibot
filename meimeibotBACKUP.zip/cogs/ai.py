import discord

from discord.ext import commands

import asyncio

from google import genai

from google.genai import errors, types

from config import GEMINI_API_KEY_PATH
import os

from pathlib import Path


with open(GEMINI_API_KEY_PATH, "r") as f:
    GEMINI_API_KEY = f.read()

class AI(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command()
    @commands.cooldown(1, 10, commands.BucketType.user)
    @commands.has_any_role(1561325307208929280)  # TODO: Remove hardcoded ID
    async def ai(self, ctx, *, question):
        client = genai.Client(api_key=GEMINI_API_KEY)

        with open("/home/benjisrpi/Documents/FoC/src/meimeibot/data/AI_Instructions.txt", "r", encoding="utf-8") as f:
            instructions = f.read()

        user_info = f"""
            User information:
            - Username: {ctx.author}
            - User ID: {ctx.author.id}
            - Display name: {ctx.author.display_name}
            - Server: {ctx.guild.name}
            - Roles: {', '.join(role.name for role in ctx.author.roles)}
            - Is server administrator: {ctx.author.guild_permissions.administrator}
            """

        try:
            response = await asyncio.to_thread(
                client.models.generate_content,
                model="gemini-3.5-flash-lite",
                contents=f"{user_info}\n\nUser Question: {question}",
                config=types.GenerateContentConfig(
                    system_instruction=instructions,
                )
            )

            await ctx.reply(response.text or "I'm just not gonna give you a response, okay?")

        except errors.APIError as e:
            await ctx.reply(f"Gemini API error: {e}")

        except Exception as e:
            print(f"Unexpected error: {type(e).__name__}: {e}")
            await ctx.reply("Something went wrong while contacting Myself.")


async def setup(bot):
    await bot.add_cog(AI(bot))