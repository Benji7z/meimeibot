import random

import discord

from datetime import timedelta

from discord.ext import commands

from data.questions import questions

import edge_tts

import asyncio

class HeresyView(discord.ui.View):

    def __init__(self, answer):
        super().__init__(timeout=None)
        self.answer = answer
        self.guessed_users = set()
        
    async def on_timeout(self):
        for item in self.children:
            item.disabled = True
        if self.message:
            try:
                await self.message.edit(view=self)
            except discord.HTTPException:
                pass
        

    async def answer_question(self, interaction, correct):
        if interaction.user.id in self.guessed_users:
            await interaction.response.send_message(
                "You already guessed!",
                ephemeral=True
            )
            return

        self.guessed_users.add(interaction.user.id)

        if self.answer == correct:
            await interaction.response.send_message(
                f"{interaction.user.mention} gave the correct answer! ✅",
                ephemeral=False
            )
        else:
            await interaction.response.send_message(
                f"{interaction.user.mention} GOT THE QUESTION **WRONG** ❌",
                ephemeral=False
            )
            await interaction.user.timeout(timedelta(minutes=1))

    @discord.ui.button(label="Heresy", style=discord.ButtonStyle.danger)
    async def heresy(
        self,
        interaction: discord.Interaction,
        button: discord.ui.Button
    ):
        await self.answer_question(interaction, "heresy")

    @discord.ui.button(label="Not heresy", style=discord.ButtonStyle.success)
    async def not_heresy(
        self,
        interaction: discord.Interaction,
        button: discord.ui.Button
    ):
        await self.answer_question(interaction, "not_heresy")

    @discord.ui.button(label="Another question", style=discord.ButtonStyle.primary)
    async def another_question(
        self,
        interaction: discord.Interaction,
        button: discord.ui.Button
    ):
        question, answer = random.choice(questions)

        embed = discord.Embed(
            title="Heresy or not",
            description=question,
            color=discord.Color.blurple()
        )

        await interaction.response.send_message(
            embed=embed,
            view=HeresyView(answer)
        )


class Fun(commands.Cog):

    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="8ball")
    @commands.cooldown(1, 60, commands.BucketType.user)
    async def eightball(self, ctx, *, question):

        answers = [
            "Yes.", "No.", "Probably.", "Probably not.",
            "Definitely.", "Definitely not.", "It is certain.",
            "Very unlikely."
        ]

        embed = discord.Embed(
            title=question,
            description=random.choice(answers),
            color=discord.Color.blurple()
        )

        await ctx.reply(embed=embed)

    @commands.command()
    async def whatappamiusing(self, ctx):
        await ctx.reply("You're using discord.")

    @commands.command()
    async def heresyornot(self, ctx):

        question, answer = random.choice(questions)

        embed = discord.Embed(
            title="Heresy or not",
            description=question,
            color=discord.Color.blurple()
        )

        await ctx.reply(
            embed=embed,
            view=HeresyView(answer)
        )
    @commands.command()
    @commands.has_permissions(administrator=True)
    async def join(self, ctx):
        await ctx.message.delete()
        if ctx.author.voice and ctx.author.voice.channel:
            channel = ctx.author.voice.channel

            if ctx.voice_client is None:
                await channel.connect()
            else:
                await ctx.voice_client.move_to(channel)
        else:
            await ctx.send("You are not in a voice channel!")


    @commands.command()
    @commands.has_permissions(administrator=True)
    async def leave(self, ctx):
        await ctx.message.delete()
        if ctx.voice_client:
            await ctx.voice_client.disconnect()
    
    @commands.command()
    async def say(self, ctx, *, text):
        await ctx.message.delete()
        if not ctx.voice_client:
            await ctx.send("I'm not in a voice channel.")
            return

        communicate = edge_tts.Communicate(
            text,
            "en-US-AriaNeural"
        )

        await communicate.save("/tmp/speech.mp3")

        source = discord.FFmpegPCMAudio("/tmp/speech.mp3")
        ctx.voice_client.play(source)

        print(f"VOICE ERROR: {type(e).__name__}: {e}")
        await ctx.send(f"Voice error: `{type(e).__name__}: {e}`")

async def setup(bot):
    await bot.add_cog(Fun(bot)) 